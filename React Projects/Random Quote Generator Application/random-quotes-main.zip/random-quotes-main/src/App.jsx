import Quotes from "./Dashboard/Quotes/Quotes";
import Footer from "./Dashboard/Components/Footer";

function App() {
  return (
    <div className="App">
      <Quotes />
      <Footer />
    </div>
  );
}

export default App;
