export const COPY_SUCCESS = "Password successfully copied to clipboard";
export const ALERT = "You must select at least one option";
