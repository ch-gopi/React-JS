export const numbers = "0123456789";
export const upperCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
export const lowerCaseLettters = "abcdefghijklmnopqrstuvwxyz";
export const specialCharacters = "!'^+%&/()=?_#$½§{[]}|;:>÷`<.*-@é"